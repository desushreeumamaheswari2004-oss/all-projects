﻿using System;

namespace LibraryManagementConsoleApp
{
    class Program
    {
        static void Main()
        {
            Library library = new Library();
            int choice;

            do
            {
                Console.WriteLine("\n--- Library Management System ---");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. Register Borrower");
                Console.WriteLine("3. Borrow Book");
                Console.WriteLine("4. Return Book");
                Console.WriteLine("0. Exit");
                Console.Write("Enter choice: ");

                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Title: ");
                        string title = Console.ReadLine();
                        Console.Write("Author: ");
                        string author = Console.ReadLine();
                        Console.Write("ISBN: ");
                        string isbn = Console.ReadLine();
                        library.AddBook(new Book(title, author, isbn));
                        break;

                    case 2:
                        Console.Write("Name: ");
                        string name = Console.ReadLine();
                        Console.Write("Card Number: ");
                        string card = Console.ReadLine();
                        library.RegisterBorrower(new Borrower(name, card));
                        break;

                    case 3:
                        Console.Write("ISBN: ");
                        string bIsbn = Console.ReadLine();
                        Console.Write("Card Number: ");
                        string bCard = Console.ReadLine();
                        library.BorrowBook(bIsbn, bCard);
                        break;

                    case 4:
                        Console.Write("ISBN: ");
                        string rIsbn = Console.ReadLine();
                        Console.Write("Card Number: ");
                        string rCard = Console.ReadLine();
                        library.ReturnBook(rIsbn, rCard);
                        break;
                }

            } while (choice != 0);
        }
    }
}