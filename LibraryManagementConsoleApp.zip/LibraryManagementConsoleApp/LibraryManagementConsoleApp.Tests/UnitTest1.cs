﻿using NUnit.Framework;
using LibraryManagementConsoleApp;

namespace LibraryManagementConsoleApp.Tests
{
    [TestFixture]
    public class UnitTest1
    {
        private Library library;

        [SetUp]
        public void Setup()
        {
            library = new Library();
        }

        [Test]
        public void BorrowBook_Test()
        {
            var book = new Book("C#", "Author", "101");
            var borrower = new Borrower("Uma", "CARD01");

            library.AddBook(book);
            library.RegisterBorrower(borrower);
            library.BorrowBook("101", "CARD01");

            Assert.That(book.IsBorrowed, Is.True);
        }

        [Test]
        public void ReturnBook_Test()
        {
            var book = new Book("C#", "Author", "101");
            var borrower = new Borrower("Uma", "CARD01");

            library.AddBook(book);
            library.RegisterBorrower(borrower);
            library.BorrowBook("101", "CARD01");
            library.ReturnBook("101", "CARD01");

            Assert.That(book.IsBorrowed, Is.False);
        }
    }
}