﻿using System;

namespace CalculatorApp
{
    public class Calculator
    {
        public int Add(int a, int b) => a + b;
        public int Subtract(int a, int b) => a - b;
        public int Multiply(int a, int b) => a * b;

        public int Divide(int a, int b)
        {
            if (b == 0)
                throw new DivideByZeroException("Cannot divide by zero");
            return a / b;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Calculator calc = new Calculator();

            Console.WriteLine(calc.Add(10, 5));
            Console.WriteLine(calc.Subtract(10, 5));
            Console.WriteLine(calc.Multiply(10, 5));
            Console.WriteLine(calc.Divide(10, 5));

            Console.ReadLine();
        }
    }
}